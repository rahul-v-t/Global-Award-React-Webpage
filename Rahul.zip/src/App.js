import './App.css';
import Award from './components/screens/Award';


function App() {
  return (
    <Award />
  );
}

export default App;
